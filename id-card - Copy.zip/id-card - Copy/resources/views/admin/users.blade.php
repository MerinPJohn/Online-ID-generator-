@extends('admin.layout.page')
@section('title')
     Users List
@endsection
@section('styles')
    <style>
        .space {
            margin-top: 7%;
        }

        .heading {
            padding-left: 4%;
            padding-bottom: 2%;
        }
    </style>
@endsection
@section('content')
    <div class="space">
        <h3 class="heading"> Users List</h3>
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Contact</th>
                    <th scope="col">joined On</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $key => $user)
                    <tr>
                        <th scope="row">{{ ++$key }}</th>
                        <td>{{ $user->first_name." ".$user->last_name }}
                          <td>  {{ $user->email }} </td>
                           <td> {{ $user->address }}</td>
                      
                        <td> {{$user->phone}}</td>
                        <td>
                          {{$user->created_at}}
                        </td>
                        
                    </tr>
                @endforeach


            </tbody>
        </table>
    </div>
@endsection
