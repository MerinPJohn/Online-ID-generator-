@extends('admin.layout.page')
@section('title')
     Orgnization List
@endsection
@section('styles')
    <style>
        .space {
            margin-top: 7%;
        }

        .heading {
            padding-left: 4%;
            padding-bottom: 2%;
        }
    </style>
@endsection
@section('content')
    <div class="space">
        <h3 class="heading"> Organization List</h3>
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Logo</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Date</th>
                    <th scope="col">Owned By</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orgList as $key => $org)
                    <tr>
                        <th scope="row">{{ ++$key }}</th>
                        <td>{{ $org->name }} <br>
                            {{ $org->email }} <br>
                            {{ $org->address }}
                        </td>
                            <td class="text-center">
                              <img class="pic"
                                  src="{{Storage::url('logo/' . $org->logo)}}"
                                  alt="">
                          </td>
                        <td> {{$org->phone}}</td>
                        <td>
                          {{$org->created_at}}
                        </td>
                        <td>
                         {{$org->first_name." ".$org->last_name}}
                        </td>
                    </tr>
                @endforeach


            </tbody>
        </table>
    </div>
@endsection
