<!DOCTYPE html>
<html lang="en">

<head>
    <title> @yield('title')</title>
    @include('layout.header')
    <link rel="stylesheet" type="text/css"  href="{{asset('assets/css/org.css')}}">
    @yield('styles')
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    @include('admin.navbar.navbar')

    @yield('content')

    @yield('scripts')

</body>

</html>
