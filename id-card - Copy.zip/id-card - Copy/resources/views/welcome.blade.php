@extends('layout.page')
@section('title')
    Registration
@endsection

@section('styles')

@endsection

@section('content')



    @endsection

@section('scripts')
@endsection