@extends('layout.page')
@section('title')
    Verify
@endsection

@section('styles')
<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/login.css')}}">
@endsection

@section('content')

<div class="register-photo">
<br><br><br>

    <div class="form-container">
        <div class="image-holder"></div>
        <form method="POST" action="{{route('verify')}}">
            @csrf
            <h4 style="color: red;">  {{session('message')}}</h4>
            <h2 class="text-center"><strong>Welcome back!</strong></h2>
           
            <div class="form-group"><input class="form-control" type="text" name="code" placeholder="id code"></div>
          
            <div class="form-group">
                <div class="d-flex justify-content-between">
      
    </div>
            </div>
            <div class="form-group"><button class="btn btn-success btn-block btn-info" type="submit">Submit</button></div>
        </form>
    </div>
</div>

@endsection

@section('scripts')
@endsection