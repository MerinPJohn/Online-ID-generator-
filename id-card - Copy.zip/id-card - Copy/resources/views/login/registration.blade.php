@extends('layout.page')
@section('title')
    Registration
@endsection

@section('styles')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/login.css') }}">
@endsection

@section('content')
    <br><br>
    <div class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" action="{{ route('register') }}">
                @csrf
                <h2 class="text-center"><strong>Create</strong> an account.</h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    @if ($errors->has('email'))
                        <span class="text-danger">{{ $errors->first('email') }}</span>
                    @endif
                </div>
                <div class="form-group"><input class="form-control" type="text" name="first_name"
                        placeholder="First Name">
                    @if ($errors->has('first_name'))
                        <span class="text-danger">{{ $errors->first('first_name') }}</span>
                    @endif
                </div>
                <div class="form-group"><input class="form-control" type="text" name="last_name" placeholder="Last Name">
                    @if ($errors->has('last_name'))
                        <span class="text-danger">{{ $errors->first('last_name') }}</span>
                    @endif
                </div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="address">
                    @if ($errors->has('address'))
                        <span class="text-danger">{{ $errors->first('address') }}</span>
                    @endif
                </div>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password">
                    @if ($errors->has('password'))
                        <span class="text-danger">{{ $errors->first('password') }}</span>
                    @endif
                </div>
                <div class="form-group"><input class="form-control" type="password" name="password_confirmation"
                        placeholder="Password (repeat)">
                    @if ($errors->has('password_confirmation'))
                        <span class="text-danger">{{ $errors->first('password_confirmation') }}</span>
                    @endif
                </div>

                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Sign Up</button></div><a
                    class="already" href="{{route('login')}}">You already have an account? Login here.</a>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
@endsection
