@extends('layout.page')
@section('title')
 {{$org->name}}|view
@endsection

@section('styles')
<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/org.css')}}">
<link rel="stylesheet" type="text/css"  href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
@endsection

@section('content')
<div style="background-color:#93bfc7;min-height:500px;">
<br><br><br>
<br><br><br> 
<div class="container">
    <a href="{{route('addCardHolder',$org->id)}}" class="btn btn-success">+ Add New </a>
        <div class="table-wrap"  style="background-color:white;">
            <table class="table table-responsive">
                <thead>
                <th>&nbsp;</th>
                    <th>Image</th>
                    <th>Name</th>
                   
                    <th>Designation</th>
                    <th>Company</th>
                    <th>Dob</th> 
                    <th>Gender</th>
                    <th>Blood Group</th>
                  
                    <th>Action</th>
                </thead>
                <tbody>
                 @foreach ( $cardHolders as $cardHolder )
                 <tr class="align-middle alert border-bottom" role="alert">
                    <td></td>
                        <td class="text-center">
                            <img class="pic"
                                src="{{Storage::url('user_image/' . $cardHolder->image)}}"
                                alt="">
                        </td>
                        <td>
                            <div>
                              {{$cardHolder->first_name." ".$cardHolder->last_name}} <br>
                                {{$cardHolder->address}} <br>
                                {{$cardHolder->email}} <br>
                                {{$cardHolder->phone}} <br>
                                Id Code :  {{$cardHolder->card_holder_code}}
                            </div>
                        </td>
                       
                        <td> {{$cardHolder->designation}} </td>
                        <td> {{$cardHolder->company}} </td>
                        <td> {{$cardHolder->dob}} </td>
                        <td> {{$cardHolder->gender}} </td>
                        <td> {{$cardHolder->blood_group}} </td>
                        <td>
                     
                            <a href="{{route('viewCardHolder',[$cardHolder->org_id,$cardHolder->id])}}" class="btn btn-info">View</a>
                            <a href="{{route('deleteCardHolder',[$cardHolder->org_id,$cardHolder->id])}}" class="btn btn-danger">Delete</a>
                        
                       

                        </td>
                    </tr>  
                 @endforeach
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
    @endsection

@section('scripts')
@endsection