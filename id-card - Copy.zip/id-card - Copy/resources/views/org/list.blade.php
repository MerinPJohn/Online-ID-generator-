@extends('layout.page')
@section('title')
    Organization list
@endsection

@section('styles')
<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/org.css')}}">
<link rel="stylesheet" type="text/css"  href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
@endsection

@section('content')
<div style="background-color:#93bfc7;min-height:500px;">
<br><br><br>
<br><br><br> 
<div class="container">
    <a href="{{route('addOrg')}}" class="btn btn-success">+ Add New </a>
        <div class="table-wrap"  style="background-color:white;">
            <table class="table table-responsive">
                <thead>
                <th>&nbsp;</th>
                    <th>logo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>&nbsp;</th>
                    <th>Action</th>
                </thead>
                <tbody>
                 @foreach ( $orgLists as $list )
                 <tr class="align-middle alert border-bottom" role="alert">
                    <td></td>
                        <td class="text-center">
                            <img class="pic"
                                src="{{Storage::url('logo/' . $list->logo)}}"
                                alt="">
                        </td>
                        <td>
                            <div>
                                <p class="m-0 fw-bold">{{$list->name}}</p>
                            </div>
                        </td>
                        <td>
                            <div class="fw-600">{{$list->address}}</div>
                        </td>
                        <td>
                            <div class="fw-600">{{$list->email}}</div>
                        </td>
                        <td>
                            {{$list->phone}}
                        </td>
                        <td> </td>
                        <td>
                        @if ($list->status)
                        <a href="{{route('viewOrg',$list->id)}}" class="btn btn-info">View</a>
                        <a href="{{route('deleteOrg',$list->id)}}" class="btn btn-danger">Delete</a>
                         @elseif(!$list->isRejected)
                         <button type="button" disabled class="btn btn-warning">Wating for Approval</button>
                         @else
                         <button type="button" disabled class="btn btn-danger">Rejected</button>
                        @endif

                        </td>
                    </tr>  
                 @endforeach
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
    @endsection

@section('scripts')
@endsection