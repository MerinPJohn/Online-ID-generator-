@extends('layout.page')
@section('title')
   Add Organization
@endsection

@section('styles')
<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/login.css')}}">
@endsection

@section('content')
<br><br>
<div class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" action="{{route('saveOrg')}}" enctype="multipart/form-data">
                @csrf
                <h2 class="text-center"><strong>Register</strong> Organization</h2>
                <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Name">
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('name') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="Address">
                    @if ($errors->has('address'))
                    <span class="text-danger">{{ $errors->first('address') }}</span>
                @endif</div>

                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    @if ($errors->has('email'))
                    <span class="text-danger">{{ $errors->first('email') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="Contact" name="phone" placeholder="Contact">
                    @if ($errors->has('phone'))
                    <span class="text-danger">{{ $errors->first('phone') }}</span>
                @endif</div>
				<div class="form-group">Logo<input type="file" name="logo" class="form-control" required>
                    @if ($errors->has('logo'))
                    <span class="text-danger">{{ $errors->first('logo') }}</span>
                @endif</div>
               
                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Save</button></div>
			</form>
        </div>
    </div>


    @endsection

@section('scripts')
@endsection