<!DOCTYPE html>
<html lang="en">
<head>
    <title> @yield('title')</title>
    @include('layout.header')
    @yield('styles')
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
     @include('navbar.navbar')
    
     @yield('content')

     @include('layout.footer')
     @yield('scripts')
   
</body>
</html>
