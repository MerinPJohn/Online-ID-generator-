<link rel="stylesheet" href="{{asset('assets/css/dashboard1.css')}}">

<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/bootstrap.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/fonts/font-awesome/css/font-awesome.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900" rel="stylesheet">

