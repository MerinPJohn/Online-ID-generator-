@extends('layout.page')
@section('title')
    Registration
@endsection

@section('styles')

<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/card.css')}}">
<link rel="stylesheet" type="text/css"  href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css">
<link rel="stylesheet" href="{{asset('assets/css/print.css')}}" media="print">
@endsection

@section('content')
<div style="margin:150px 500px 100px;padding:20px;">
	<div class="card p-4" style="padding:20px;" id='printable_div_id'>
			
		<div class="top-container d-flex justify-content-start align-items-center">

			<div class="round-div"><img src="{{Storage::url('logo/' . $org->logo)}}" class="round-div"></div>
			<span class="shipped pl-2 text-center">IDENTITY CARD</span>
			
		</div>


		<div class="middle-container pt-4 d-flex align-items-center justify-content-between">
			
			<div><img src="{{Storage::url('user_image/' . $cardHolder->image)}}" class="img-fluid " width="170px" height="170px"></div>

			<div class="d-flex flex-column text-left" style="margin-top:30px;">
            <span class="item-quantity">ID          :</span> <span class="item-price">{{$cardHolder->card_holder_code}}</span><br><br>
            <span class="item-quantity">Organization &nbsp:</span><span class="item-name"> {{$org->name}}</span> <br>
            <span class="item-quantity">Name &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :</span><span class="item-name"> {{$cardHolder->first_name}} {{$cardHolder->last_name}}</span> <br>
            <span class="item-quantity">Date Of Birth&nbsp :</span><span class="item-name"> {{$cardHolder->dob}}</span> <br>
            <span class="item-quantity">Role &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :</span><span class="item-name"> {{$cardHolder->designation}}</span> <br>
            <span class="item-quantity">Address &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :</span><span class="item-name"> {{$cardHolder->address}}</span> <br>
			<span class="item-quantity">Blood Group &nbsp&nbsp :</span><span class="item-name"> {{$cardHolder->blood_group}}</span> <br>
            <span class="item-quantity">Contact &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :</span><span class="item-name"> {{$cardHolder->phone}}</span> <br>
	
    
    
        </div>
		</div>

	</div>	
<button class="btn btn-success" style="float:right;margin-top:50px;height:50px;padding:10px;" onclick="printdiv('printable_div_id');">Print Card </button>
</div>
    @endsection

@section('scripts')
<script type="text/javascript">

function printdiv(elem) {
  var header_str = '<html><head><title>' + document.title  + '</title><link href="//assets/css/print.css"></head><body bgcolor="red">';
  var footer_str = '</body></html>';
  var new_str = document.getElementById(elem).innerHTML;
  var old_str = document.body.innerHTML;
  document.body.innerHTML = header_str + new_str + footer_str;
  window.print(document.body.innerHTML);
  document.body.innerHTML = old_str;
  return false;
}
</script>
@endsection