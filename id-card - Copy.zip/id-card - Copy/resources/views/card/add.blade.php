@extends('layout.page')
@section('title')
   Add New Card Holder
@endsection

@section('styles')
<link rel="stylesheet" type="text/css"  href="{{asset('assets/css/login.css')}}">
<style>
    .space {
        margin-bottom: 18%;
    }
    </style>
@endsection

@section('content')
<br><br>
<div class="register-photo">
        <div class="form-container" >
            <div class="image-holder"></div>
            <form method="post" action="{{route('saveCardHolder')}}" enctype="multipart/form-data" >
                @csrf
                <input type="hidden" name="org_id" value="{{$id}}">
                <h2 class="text-center"><strong>Register</strong> New Id Card</h2>
                <div class="form-group"><input class="form-control" type="text" name="first_name" placeholder="first_name">
                    @if ($errors->has('first_name'))
                    <span class="text-danger">{{ $errors->first('first_name') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="text" name="last_name" placeholder="last_name">
                    @if ($errors->has('last_name'))
                    <span class="text-danger">{{ $errors->first('last_name') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="Address">
                    @if ($errors->has('address'))
                    <span class="text-danger">{{ $errors->first('address') }}</span>
                @endif</div>

                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    @if ($errors->has('email'))
                    <span class="text-danger">{{ $errors->first('email') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="Contact" name="phone" placeholder="Contact">
                    @if ($errors->has('phone'))
                    <span class="text-danger">{{ $errors->first('phone') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="location" name="location" placeholder="location">
                    @if ($errors->has('location'))
                    <span class="text-danger">{{ $errors->first('location') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="designation" name="designation" placeholder="designation">
                    @if ($errors->has('designation'))
                    <span class="text-danger">{{ $errors->first('designation') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="company" name="company" placeholder="company">
                    @if ($errors->has('company'))
                    <span class="text-danger">{{ $errors->first('designation') }}</span>
                @endif</div>
                 <div class="form-group"><input class="form-control" type="gender" name="gender" placeholder="gender">
                    @if ($errors->has('gender'))
                    <span class="text-danger">{{ $errors->first('gender') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="date" name="dob" placeholder="dob">
                    @if ($errors->has('dob'))
                    <span class="text-danger">{{ $errors->first('dob') }}</span>
                @endif</div>
                <div class="form-group"><input class="form-control" type="text" name="blood_group" placeholder="blood_group">
                    @if ($errors->has('blood_group'))
                    <span class="text-danger">{{ $errors->first('blood_group') }}</span>
                @endif</div>
				<div class="form-group">Image<input type="file" name="image" class="form-control" required>
                    @if ($errors->has('image'))
                    <span class="text-danger">{{ $errors->first('image') }}</span>
                @endif</div>
               
                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Save</button></div>
                <span>*Once an ID is created, you cannot edit it</span>
			</form>
        </div>
    </div>
    <div class="space">
       
    </div>

    @endsection

@section('scripts')
@endsection