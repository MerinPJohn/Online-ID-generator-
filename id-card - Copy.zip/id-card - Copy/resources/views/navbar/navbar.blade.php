@php
  $user_id = Auth::id();
@endphp
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="{{route('index')}}">ID Generator</a> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#features" class="page-scroll">Features</a></li>
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#services" class="page-scroll">Our Clients</a></li>
        <li><a href="{{route('verify')}}" class="page-scroll">Verify</a></li>
        @if (empty($user_id))
          <li><a href="{{route('login')}}" class="page-scroll">Login</a></li>
        @else
        <li><a href="{{route('org')}}" class="page-scroll">My Org</a></li>
        <li><a href="{{route('logout')}}" class="page-scroll">Logout</a></li>
        @endif
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
</nav>