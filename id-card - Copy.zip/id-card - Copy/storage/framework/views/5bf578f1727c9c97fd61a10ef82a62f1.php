<!DOCTYPE html>
<html lang="en">

<head>
    <title> <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/org.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <?php echo $__env->make('admin.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/admin/layout/page.blade.php ENDPATH**/ ?>