<?php $__env->startSection('title'); ?>
    Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/add.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br><br><br>
<form>
<div class="wrapper rounded " style="background-color:white;">

        <div class="h3">Create ID details</div>

        <div class="form">
            <div class="row">
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Name</label>
                    <input type="text" class="form-control" required>
                </div>
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Address </label>
                    <input type="text" class="form-control" required>
                </div>
            </div>
            <div class="row">
            <div class="col-md-6 mt-md-0 mt-3">
                    <label>Role </label>
                    <input type="text" class="form-control" required>
                </div>
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Gender</label>
                    <div class="d-flex align-items-center mt-2">
                        <label class="option">
                            <input type="radio" name="gender" value="m">Male
                            <span class="checkmark"></span>
                        </label>
                        <label class="option ms-4">
                            <input type="radio" name="gender" value="f">Female
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Age</label>
                    <input type="email" class="form-control" required>
                </div>
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Blood Group</label>
                    <select id="sub" required>
                    <option value="" selected hidden>Choose Option</option>
                    <option value="A+">A+</option>
                    <option value="B+">B+</option>
                    <option value="A-">A-</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Email</label>
                    <input type="email" class="form-control" required>
                </div>
                <div class="col-md-6 mt-md-0 mt-3">
                    <label>Phone Number</label>
                    <input type="tel" class="form-control" required>
                </div>
            </div>

            <div class=" my-md-2 my-3">
                <label>Photo</label>
                <input type="file" class="form-control" required>
            </div>
<br>
            <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </div>

    </div>

</form>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/user/add_employee.blade.php ENDPATH**/ ?>