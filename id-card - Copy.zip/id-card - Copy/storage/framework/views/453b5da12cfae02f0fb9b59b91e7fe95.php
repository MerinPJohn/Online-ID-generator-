<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="register-photo">
<br><br><br>

    <div class="form-container">
        <div class="image-holder"></div>
        <form method="POST" action="<?php echo e(route('authenticate')); ?>">
            <?php echo csrf_field(); ?>
            <h4 style="color: green;">  <?php echo e(session('message')); ?></h4>
            <h2 class="text-center"><strong>Welcome back!</strong></h2>
           
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email"></div>
            <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password"></div>
            <div class="form-group">
                <div class="d-flex justify-content-between">
         <a href="<?php echo e(route('registration')); ?>">Sign Up Here</a>
        <!-- <div> <a href="#" class="text-info">Forgot Password</a> </div> -->
    </div>
            </div>
            <div class="form-group"><button class="btn btn-success btn-block btn-info" type="submit">Login</button></div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/login/login.blade.php ENDPATH**/ ?>