<?php $__env->startSection('title'); ?>
    Organization list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/org.css')); ?>">
<link rel="stylesheet" type="text/css"  href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-color:#93bfc7;min-height:500px;">
<br><br><br>
<br><br><br> 
<div class="container">
    <a href="<?php echo e(route('addOrg')); ?>" class="btn btn-success">+ Add New </a>
        <div class="table-wrap"  style="background-color:white;">
            <table class="table table-responsive">
                <thead>
                <th>&nbsp;</th>
                    <th>logo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>&nbsp;</th>
                    <th>Action</th>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $orgLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="align-middle alert border-bottom" role="alert">
                    <td></td>
                        <td class="text-center">
                            <img class="pic"
                                src="<?php echo e(Storage::url('logo/' . $list->logo)); ?>"
                                alt="">
                        </td>
                        <td>
                            <div>
                                <p class="m-0 fw-bold"><?php echo e($list->name); ?></p>
                            </div>
                        </td>
                        <td>
                            <div class="fw-600"><?php echo e($list->address); ?></div>
                        </td>
                        <td>
                            <div class="fw-600"><?php echo e($list->email); ?></div>
                        </td>
                        <td>
                            <?php echo e($list->phone); ?>

                        </td>
                        <td> </td>
                        <td>
                        <?php if($list->status): ?>
                        <a href="<?php echo e(route('viewOrg',$list->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('deleteOrg',$list->id)); ?>" class="btn btn-danger">Delete</a>
                         <?php elseif(!$list->isRejected): ?>
                         <button type="button" disabled class="btn btn-warning">Wating for Approval</button>
                         <?php else: ?>
                         <button type="button" disabled class="btn btn-danger">Rejected</button>
                        <?php endif; ?>

                        </td>
                    </tr>  
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/org/list.blade.php ENDPATH**/ ?>