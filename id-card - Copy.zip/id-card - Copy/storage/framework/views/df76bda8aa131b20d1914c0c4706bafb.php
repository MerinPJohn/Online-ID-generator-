<?php $__env->startSection('title'); ?>
     Users List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .space {
            margin-top: 7%;
        }

        .heading {
            padding-left: 4%;
            padding-bottom: 2%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="space">
        <h3 class="heading"> Users List</h3>
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Contact</th>
                    <th scope="col">joined On</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($user->first_name." ".$user->last_name); ?>

                          <td>  <?php echo e($user->email); ?> </td>
                           <td> <?php echo e($user->address); ?></td>
                      
                        <td> <?php echo e($user->phone); ?></td>
                        <td>
                          <?php echo e($user->created_at); ?>

                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/admin/users.blade.php ENDPATH**/ ?>