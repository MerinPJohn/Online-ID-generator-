<?php $__env->startSection('title'); ?>
    Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <h2 class="text-center"><strong>Create</strong> an account.</h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group"><input class="form-control" type="text" name="first_name"
                        placeholder="First Name">
                    <?php if($errors->has('first_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group"><input class="form-control" type="text" name="last_name" placeholder="Last Name">
                    <?php if($errors->has('last_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="address">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password">
                    <?php if($errors->has('password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group"><input class="form-control" type="password" name="password_confirmation"
                        placeholder="Password (repeat)">
                    <?php if($errors->has('password_confirmation')): ?>
                        <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Sign Up</button></div><a
                    class="already" href="<?php echo e(route('login')); ?>">You already have an account? Login here.</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/login/registration.blade.php ENDPATH**/ ?>