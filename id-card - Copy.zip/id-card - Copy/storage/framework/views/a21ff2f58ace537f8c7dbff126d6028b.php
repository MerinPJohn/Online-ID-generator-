<?php $__env->startSection('title'); ?>
 <?php echo e($org->name); ?>|view
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/org.css')); ?>">
<link rel="stylesheet" type="text/css"  href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-color:#93bfc7;min-height:500px;">
<br><br><br>
<br><br><br> 
<div class="container">
    <a href="<?php echo e(route('addCardHolder',$org->id)); ?>" class="btn btn-success">+ Add New </a>
        <div class="table-wrap"  style="background-color:white;">
            <table class="table table-responsive">
                <thead>
                <th>&nbsp;</th>
                    <th>Image</th>
                    <th>Name</th>
                   
                    <th>Designation</th>
                    <th>Company</th>
                    <th>Dob</th> 
                    <th>Gender</th>
                    <th>Blood Group</th>
                  
                    <th>Action</th>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $cardHolders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cardHolder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="align-middle alert border-bottom" role="alert">
                    <td></td>
                        <td class="text-center">
                            <img class="pic"
                                src="<?php echo e(Storage::url('user_image/' . $cardHolder->image)); ?>"
                                alt="">
                        </td>
                        <td>
                            <div>
                              <?php echo e($cardHolder->first_name." ".$cardHolder->last_name); ?> <br>
                                <?php echo e($cardHolder->address); ?> <br>
                                <?php echo e($cardHolder->email); ?> <br>
                                <?php echo e($cardHolder->phone); ?> <br>
                                Id Code :  <?php echo e($cardHolder->card_holder_code); ?>

                            </div>
                        </td>
                       
                        <td> <?php echo e($cardHolder->designation); ?> </td>
                        <td> <?php echo e($cardHolder->company); ?> </td>
                        <td> <?php echo e($cardHolder->dob); ?> </td>
                        <td> <?php echo e($cardHolder->gender); ?> </td>
                        <td> <?php echo e($cardHolder->blood_group); ?> </td>
                        <td>
                     
                            <a href="<?php echo e(route('viewCardHolder',[$cardHolder->org_id,$cardHolder->id])); ?>" class="btn btn-info">View</a>
                            <a href="<?php echo e(route('deleteCardHolder',[$cardHolder->org_id,$cardHolder->id])); ?>" class="btn btn-danger">Delete</a>
                        
                       

                        </td>
                    </tr>  
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/org/view.blade.php ENDPATH**/ ?>