<?php $__env->startSection('title'); ?>
    Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/req.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<br><br><br><br><br><br>
<div class="container rounded mt-5 bg-white p-md-5"  style="background-color:white;">
    <div class="h2 font-weight-bold text-center">Requests</div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>                    
                    <th scope="col">Address</th>                    
                    <th scope="col">Email</th>                    
                    <th scope="col">Contact</th>  
                    <th scope="col">Action</th>                    

                </tr>
            </thead>
            <tbody>
                <tr class="bg-blue">            
                    <td class="pt-2">
                        <img src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" class="rounded-circle" alt=""> 
                        <div class="pl-lg-5 pl-md-3 pl-1 name">name</div>
                    </td>                
                    <td class="pt-3 mt-1">address1</td>
                    <td class="pt-3">email122</td>
                    <td class="pt-3">123456789</td>
                    <td class="pt-3">
                        <button type="button" class="btn btn-success">Approve</button>
                         <button type="button" class="btn btn-danger">Reject</button></td>
                </tr>
                <tr id="spacing-row">
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<br><br><br>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/admin/request_list.blade.php ENDPATH**/ ?>