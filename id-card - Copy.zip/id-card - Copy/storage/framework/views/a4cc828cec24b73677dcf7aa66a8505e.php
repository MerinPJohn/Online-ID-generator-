<!DOCTYPE html>
<html lang="en">
<head>
    <title> <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
     <?php echo $__env->make('navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
     <?php echo $__env->yieldContent('content'); ?>

     <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->yieldContent('scripts'); ?>
   
</body>
</html>
<?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/layout/page.blade.php ENDPATH**/ ?>