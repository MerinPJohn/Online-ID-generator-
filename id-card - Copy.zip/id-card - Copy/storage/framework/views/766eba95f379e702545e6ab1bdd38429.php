<?php $__env->startSection('title'); ?>
   Add Organization
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br><br>
<div class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" action="<?php echo e(route('saveOrg')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h2 class="text-center"><strong>Register</strong> Organization</h2>
                <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Name">
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="Address">
                    <?php if($errors->has('address')): ?>
                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?></div>

                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="Contact" name="phone" placeholder="Contact">
                    <?php if($errors->has('phone')): ?>
                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                <?php endif; ?></div>
				<div class="form-group">Logo<input type="file" name="logo" class="form-control" required>
                    <?php if($errors->has('logo')): ?>
                    <span class="text-danger"><?php echo e($errors->first('logo')); ?></span>
                <?php endif; ?></div>
               
                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Save</button></div>
			</form>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/org/add.blade.php ENDPATH**/ ?>