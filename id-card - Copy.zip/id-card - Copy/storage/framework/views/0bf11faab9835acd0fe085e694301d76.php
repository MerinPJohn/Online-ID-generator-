<?php $__env->startSection('title'); ?>
     Orgnization List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .space {
            margin-top: 7%;
        }

        .heading {
            padding-left: 4%;
            padding-bottom: 2%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="space">
        <h3 class="heading"> Organization List</h3>
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Logo</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Date</th>
                    <th scope="col">Owned By</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orgList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($org->name); ?> <br>
                            <?php echo e($org->email); ?> <br>
                            <?php echo e($org->address); ?>

                        </td>
                            <td class="text-center">
                              <img class="pic"
                                  src="<?php echo e(Storage::url('logo/' . $org->logo)); ?>"
                                  alt="">
                          </td>
                        <td> <?php echo e($org->phone); ?></td>
                        <td>
                          <?php echo e($org->created_at); ?>

                        </td>
                        <td>
                         <?php echo e($org->first_name." ".$org->last_name); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/admin/organization_list.blade.php ENDPATH**/ ?>