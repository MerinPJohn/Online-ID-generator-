<?php $__env->startSection('title'); ?>
    Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/card.css')); ?>">
<link rel="stylesheet" type="text/css"  href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="margin:200px 500px;padding:20px;">
	<div class="card p-4" style="padding:20px;">
			
		<div class="top-container d-flex justify-content-start align-items-center">

			<div class="round-div"><img src="<?php echo e(asset('assets/img/about.jpg')); ?>" class="round-div"></div>
			<span class="shipped pl-2 text-center">Identity Card</span>
			
		</div>


		<div class="middle-container pt-4 d-flex align-items-center justify-content-between">
			
			<div><img src="<?php echo e(asset('assets/img/about.jpg')); ?>" class="img-fluid " width="120px" height="120px"></div>

			<div class="d-flex flex-column text-left" style="margin-top:30px;">
            <span class="item-quantity">ID :</span><span class="item-price">376</span><br>
            <span class="item-quantity">Organization :</span><span class="item-name">Perfume coco</span> <br>
            <span class="item-quantity">Name :</span><span class="item-name">Perfume coco</span> <br>
            <span class="item-quantity">Age :</span><span class="item-name">46</span> <br>
            <span class="item-quantity">Role :</span><span class="item-name">Perfume coco</span> <br>
            <span class="item-quantity">Address :</span><span class="item-name">Perfume coco</span> <br>
			<span class="item-quantity">Blood Group :</span><span class="item-name">Perfume coco</span> <br>
            <span class="item-quantity">Contact :</span><span class="item-name">Perfume coco</span> <br>
	
    
    
        </div>
		</div>

	</div>
	
</div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/user/id_card.blade.php ENDPATH**/ ?>