<link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard1.css')); ?>">

<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/fonts/font-awesome/css/font-awesome.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900" rel="stylesheet">

<?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/layout/header.blade.php ENDPATH**/ ?>