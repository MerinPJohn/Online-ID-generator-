<?php $__env->startSection('title'); ?>
   Add New Card Holder
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/login.css')); ?>">
<style>
    .space {
        margin-bottom: 18%;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br><br>
<div class="register-photo">
        <div class="form-container" >
            <div class="image-holder"></div>
            <form method="post" action="<?php echo e(route('saveCardHolder')); ?>" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="org_id" value="<?php echo e($id); ?>">
                <h2 class="text-center"><strong>Register</strong> New Id Card</h2>
                <div class="form-group"><input class="form-control" type="text" name="first_name" placeholder="first_name">
                    <?php if($errors->has('first_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="text" name="last_name" placeholder="last_name">
                    <?php if($errors->has('last_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="text" name="address" placeholder="Address">
                    <?php if($errors->has('address')): ?>
                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?></div>

                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="Contact" name="phone" placeholder="Contact">
                    <?php if($errors->has('phone')): ?>
                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="location" name="location" placeholder="location">
                    <?php if($errors->has('location')): ?>
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="designation" name="designation" placeholder="designation">
                    <?php if($errors->has('designation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="company" name="company" placeholder="company">
                    <?php if($errors->has('company')): ?>
                    <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
                <?php endif; ?></div>
                 <div class="form-group"><input class="form-control" type="gender" name="gender" placeholder="gender">
                    <?php if($errors->has('gender')): ?>
                    <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="date" name="dob" placeholder="dob">
                    <?php if($errors->has('dob')): ?>
                    <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
                <?php endif; ?></div>
                <div class="form-group"><input class="form-control" type="text" name="blood_group" placeholder="blood_group">
                    <?php if($errors->has('blood_group')): ?>
                    <span class="text-danger"><?php echo e($errors->first('blood_group')); ?></span>
                <?php endif; ?></div>
				<div class="form-group">Image<input type="file" name="image" class="form-control" required>
                    <?php if($errors->has('image')): ?>
                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                <?php endif; ?></div>
               
                <div class="form-group"><button class="btn btn-success btn-block" type="submit">Save</button></div>
                <span>*Once an ID is created, you cannot edit it</span>
			</form>
        </div>
    </div>
    <div class="space">
       
    </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/card/add.blade.php ENDPATH**/ ?>