<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>We create ID<span></span></h1>
            <p>We develop a robust and user-friendly web-based ID cards. Users will have the ability to add personal information, upload photos, and generate printable ID cards.</p>
            <a href="<?php echo e(route('org')); ?>" class="btn btn-custom btn-lg page-scroll">Explore</a> </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Features Section -->
<div id="features" class="text-center">
  <div class="container">
    <div class="col-md-10 col-md-offset-1 section-title">
      <h2>Features</h2>
    </div>
    <div class="row">
      <div class="col-xs-6 col-md-3"> <i class="fa fa-line-chart"></i>
        <h3>Cost Effective</h3>
        <p>Offers pre-designed authorized ID card, eliminating the need for users to spend extra on designs.</p>
      </div>
      <div class="col-xs-6 col-md-3"> <i class="fa fa-clock-o"></i>
        <h3>Turbo</h3>
        <p>The online system generates ID cards quickly and efficiently, saving time.</p>
      </div>
      <div class="col-xs-6 col-md-3"> <i class="fa fa-group"></i>
        <h3>Authorized</h3>
        <p>Create Authorized Genuine Identity Cards.</p>
      </div>
      <div class="col-xs-6 col-md-3"> <i class="fa fa-magic"></i>
        <h3>User Friendly</h3>
        <p>Easy to use and Efficient data Handling.</p>
      </div>
    </div>
  </div>
</div>
<!-- About Section -->

<!-- Services Section -->
<div id="services" class="text-center">
  <div class="container">
    <div class="section-title">
      <h2>Our Clients</h2>
      <p>Meet Our Trusted and Wonderful Clients all over the world.</p>
    </div>
    <div class="row">
      <div class="col-md-4"> <i class="fa fa-facebook-official"></i>
        <div class="service-desc">
          <h3>Facebook</h3>
          <p>Facebook is a popular social media platform that allows users to connect with friends and family, share content, and engage in a wide range of online activities.</p>
        </div>
      </div>
      <div class="col-md-4"> <i class="fa fa-github"></i>
        <div class="service-desc">
          <h3>Github</h3>
          <p>GitHub is a web-based platform for version control and collaboration that enables developers to host, review, and manage software projects using Git.</p>
        </div>
      </div>
      <div class="col-md-4"> <i class="fa fa-twitter"></i>
        <div class="service-desc">
          <h3>Twitter</h3>
          <p>Twitter is a microblogging platform that enables users to post and interact with short messages called tweets, fostering real-time conversations and information sharing globally.</p>
        </div>
      </div>
    </div>
    
  </div>
</div>
<div id="about">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6"> <img src="<?php echo e(asset('assets/img/about.jpg')); ?>" class="img-responsive" alt=""> </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
          <h2>About Us</h2>
          <p>The ID card generator Website is dedicated to providing a user-
friendly online tool for individuals and organizations to create personalized
identification cards quickly and efficiently</p>
          <h3>Why Choose Us?</h3>
          <div class="list-style">
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <ul>
                <li>Automation</li>
                <li>Efficiency and Speed</li>
               
              </ul>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <ul>
              <li>Accessibility</li>
                <li>Cost Effective</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/index.blade.php ENDPATH**/ ?>