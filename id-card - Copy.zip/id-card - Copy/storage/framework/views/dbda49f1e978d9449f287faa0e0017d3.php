<?php $__env->startSection('title'); ?>
    Organization list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/css/org.css')); ?>">
<link rel="stylesheet" type="text/css"  href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-color:#93bfc7;height:500px;">
<br><br><br>
<br><br><br> 
<div class="container">
        <div class="table-wrap"  style="background-color:white;">
            <table class="table table-responsive">
                <thead>
                <th>&nbsp;</th>
                    <th>logo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>&nbsp;</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <tr class="align-middle alert border-bottom" role="alert">
                    <td></td>
                        <td class="text-center">
                            <img class="pic"
                                src="https://www.freepnglogos.com/uploads/shoes-png/dance-shoes-png-transparent-dance-shoes-images-5.png"
                                alt="">
                        </td>
                        <td>
                            <div>
                                <p class="m-0 fw-bold">name12</p>
                            </div>
                        </td>
                        <td>
                            <div class="fw-600">address12</div>
                        </td>
                        <td>
                            <div class="fw-600">Email123</div>
                        </td>
                        <td>
                            123456789
                        </td>
                        <td> </td>
                        <td>
                        <button type="button" class="btn btn-success">View</button>
                        <button type="button" class="btn btn-warning">Update</button>
                         <button type="button" class="btn btn-danger">Delete</button>
                        </td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Documents\GitHub\id-card\resources\views/user/organization_list.blade.php ENDPATH**/ ?>