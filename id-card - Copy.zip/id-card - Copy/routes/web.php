<?php

use Illuminate\Support\Facades\Route;


use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\OrgController;
use App\Http\Controllers\Admin\AdminController;

Route::controller(HomeController::class)->group(function(){
    Route::get('/','index')->name('index');
    Route::get('verify','verify')->name('verify');
    Route::post('verify','verifying')->name('verifying');
    
 

});
Route::controller(LoginController::class)->group(function(){
    Route::get('login','login')->name('login');
    Route::post('login','authenticate')->name('authenticate');
    Route::get('register','registration')->name('registration');
    Route::post('register','register')->name('register');
});

Route::middleware('auth')->group(function () {
    Route::get('logout',[LoginController::class,'logout'])->name('logout');
    
    Route::controller(OrgController::class)->group(function(){
       Route::get('org','index')->name('org');
       Route::get('org/add','addOrg')->name('addOrg');  
       Route::post('org/save','saveOrg')->name('saveOrg');
       Route::get('org/delete/{id}','deleteOrg')->name('deleteOrg');
       Route::get('org/view/{id}','viewOrg')->name('viewOrg');
       Route::get('org/card/add/{id}','addCardHolder')->name('addCardHolder');
       Route::post('org/card/save','saveCardHolder')->name('saveCardHolder');
       Route::get('org/card/delete/{id}/{card_id}','deleteCardHolder')->name('deleteCardHolder');
       Route::get('org/view/card/{id}/{card_id}','viewCardHolder')->name('viewCardHolder');
    });

    Route::prefix('admin')->group(function(){
        Route::controller(AdminController::class)->group(function(){
           Route::get('/','index')->name('admin');
           Route::get('approve-org/{id}/{status}','approveOrg')->name('approveOrg');
           Route::get('org','orgList')->name('orgList');
           Route::get('users','userList')->name('userList');
        });
    });

});