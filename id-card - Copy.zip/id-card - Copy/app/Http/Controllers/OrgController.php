<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validator;
use App\Http\Traits\CommonFunctions;
use App\Models\Organization;
use App\Models\CardHolder;
use Carbon\Carbon;
class OrgController extends Controller
{ 
    use CommonFunctions;
    
    public function index()  {
        $orgLists = Organization::latest()
            ->where('user_id',Auth::id())
            ->get();
        return view('org.list',compact('orgLists'));
    }
    public function addOrg()  {
        return view('org.add');
    }
    public function saveOrg(Request $request)  {
        $validatedData = Validator::make($request->all(), [
            'name' => 'bail|required',
            'address' => 'bail|required',
            'phone' => 'bail|required',
            'logo' => 'bail|required',
            'email' => 'bail|required|unique:organizations,email|email',
        ]);
        if ($validatedData->fails()) {
            return redirect(route('addOrg'))
                ->withErrors($validatedData)
                ->withInput();
        }
        $formData = $request->all();
        $formData['user_id'] = Auth::id();
        if ($request->has('logo')) {
            $formData['logo'] = $this->uploadImage($request,'logo','logo');
        }
        $org = Organization::updateOrCreate(['id' => $request->input('id')], $formData);
        return  redirect(route('org'));
    }
    public function deleteOrg($id) {
        Organization::latest()
            ->where('user_id',Auth::id())
            ->where('id',$id)
            ->delete();
        return  redirect(route('org'));
    }
    public function viewOrg($id)  {
        $org = Organization::find($id);
        $cardHolders = CardHolder::latest()
            ->where('org_id',$id)
            ->get();
        return view('org.view',compact('cardHolders','org'));
    }
    public function addCardHolder($id)  {
        return view('card.add',['id'=>$id]);
    }

    public function saveCardHolder(Request $request){
        $validatedData = Validator::make($request->all(), [
            'first_name' => 'bail|required',
            'last_name' => 'bail|required',
            'address' => 'bail|required',
            'location' => 'bail|required',
            'designation' => 'bail|required',
            'company' => 'bail|required',
            'gender' => 'bail|required',
            'dob' => 'bail|required',
            'blood_group' => 'bail|required',
            'phone' => 'bail|required',
            'image' => 'bail|required|mimes:jpeg,jpg,png,gif|max:10000',
            'email' => 'bail|required|email',
            'org_id'=> 'bail|required',
        ]);
        if ($validatedData->fails()) {
            return redirect(route('addCardHolder',$request->input('org_id')))
                ->withErrors($validatedData)
                ->withInput();
        }
        $formData = $request->all();
        $formData['owner_id'] = Auth::id();
        if ($request->has('image')) {
            $formData['image'] = $this->uploadImage($request,'image','user_image');
        }
        $org = Organization::find($request->input('org_id'));
        $formData['card_holder_code'] = strtoupper($org->name.Carbon::now());
        $card = CardHolder::updateOrCreate(['id' => $request->input('id')], $formData);
        return redirect(route('viewOrg',$request->input('org_id')));
    }
    public function deleteCardHolder($id,$card_id)  {
        CardHolder::where('id',$card_id)
            ->where('owner_id',Auth::id())
            ->where('org_id',$id)->delete();
        return redirect(route('viewOrg',$id));
    }
    public function viewCardHolder($id,$card_id) {
        $cardHolder = CardHolder::where('id',$card_id)
            ->where('owner_id',Auth::id())
            ->where('org_id',$id)->first();
        $org= Organization::find($id);
        return view('card.view',['cardHolder'=>$cardHolder,'org'=>$org]);
    }

}