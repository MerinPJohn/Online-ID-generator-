<?php

namespace App\Http\Controllers;

use App\Models\User;
use Auth;
use Illuminate\Http\Request;
use Validator;

class LoginController extends Controller
{
    public function login()
    {   if(empty(Auth::id())){
            return view('login.login');
        }else{
           return redirect(route('index'));
        }
    }
    public function authenticate(Request $request)
    {
        $validatedData = Validator::make($request->all(), [
            'password' => 'bail|required',
            'email' => 'bail|required|email',
        ]);
        if ($validatedData->fails()) {
            return redirect(route('login'))->with('message', 'Please enter valid data');
        }
        $email = $request->input('email');
        $password = $request->input('password');
        if (Auth::attempt(['email' => $email, 'password' => $password, 'status' => 1])) {
            if(Auth::user()->role==1){
                return redirect(route('admin'));
            }
            return redirect(route('index'));
        }
        return redirect('/')->with('message', 'Invalid Password');
    }
    public function registration()
    {   if(empty(Auth::id())){
            return view('login.registration');
        }else{
            return redirect(route('index'));
        }
    }
    public function register(Request $request)
    {
        $validatedData = Validator::make($request->all(), [
            'password' => 'bail|required',
            'first_name' => 'bail|required',
            'last_name' => 'bail|required',
            'password' => 'bail|required|confirmed',
            'email' => 'bail|required|unique:users,email|email',
        ]);
        if ($validatedData->fails()) {
            return redirect(route('registration'))
                ->withErrors($validatedData)
                ->withInput();
        }
        $user = new User();
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->address = $request->input('address');
        $user->role = 2;
        $user->password = bcrypt($request->input('password'));
        $user->status = true;
        $user->save();
        return redirect(route('login'))->with('message', 'Account Created ,Please Login');

    }
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->flush();
        return redirect(route('index'));
    }
}
