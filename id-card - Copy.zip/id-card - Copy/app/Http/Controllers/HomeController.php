<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CardHolder;
use Validator;
class HomeController extends Controller
{
    public function index(){
        return view('index');
    }

    public function verify()  {
        return view('verify');
    }
    public function verifying(Request $request) {
        $validatedData = Validator::make($request->all(), [
            'code' => 'bail|required',
        ]);
        if ($validatedData->fails()) {
            return redirect(route('verify'))->with('message', 'Please enter valid data');
        }
        $code = $request->input('code');
        $card = CardHolder::where('card_holder_code',$code)->first();
        if(!empty($card)){
            return redirect(route('verify'))->with('message', 'The user is verified. To know more details, please contact the company.');
        }
        return redirect(route('verify'))->with('message', 'The user is not verified ');
    }
  

}
