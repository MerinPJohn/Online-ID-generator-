<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\User;
class AdminController extends Controller
{
    public function index()
    {
        $orgList = Organization::where('status', 0)
            ->where('isRejected', false)
            ->latest()->get();
        return view('admin.dashboard', ['orgList' => $orgList]);
    }
    public function approveOrg($id, $status)
    {
        $org = Organization::find($id);
        if ($status == 1) {
            $org->status = true;
            $org->save();
        } else if ($status == 2) {
            $org->isRejected = true;
            $org->save();
        }
        return redirect(route('admin'));
    }
    public function orgList() {
        $orgList = Organization::select('organizations.*','users.first_name','users.last_name')
            ->where('organizations.status', true)
            ->where('organizations.isRejected', false)
            ->leftJoin('users', 'users.id', '=', 'organizations.user_id')
            ->latest('organizations.created_at')
            ->get();
        return view('admin.organization_list',['orgList'=>$orgList]);    
    }
    public function userList(){
        $users = User::where('role',2)
            ->latest()->get();
        return view('admin.users',['users'=>$users]); 
    }
}
